angular.module('app.services', [])



.factory('fireBaseData', function($firebase) {
	var ref = new Firebase("https://lesung-ibu-catering.firebaseio.com/"),
    //refCart = new Firebase("https://projectId.firebaseio.com/cart"),
    refUser = new Firebase("https://lesung-ibu-catering.firebaseio.com/user"),
    //refCategory = new Firebase("https://projectId.firebaseio.com/category"),
    refBook = new Firebase("https://lesung-ibu-catering.firebaseio.com/booking");
    //refFeatured = new Firebase("https://projectId.firebaseio.com/featured"),
    //refMenu = new Firebase("https://projectId.firebaseio.com/menu");
  return {
    ref: function() {
      return ref;
    },
    
    
    refUser: function() {
      return refUser;
    },
  
    refBook: function() {
      return refBook;
    }
    
  }
})


.factory('sharedUtils',['$ionicLoading','$ionicPopup', function($ionicLoading,$ionicPopup){


    var functionObj={};

    functionObj.showLoading=function(){
      $ionicLoading.show({
        content: '<i class=" ion-loading-c"></i> ', // The text to display in the loading indicator
        animation: 'fade-in', // The animation to use
        showBackdrop: true, // Will a dark overlay or backdrop cover the entire view
        maxWidth: 200, // The maximum width of the loading indicator. Text will be wrapped if longer than maxWidth
        showDelay: 0 // The delay in showing the indicator
      });
    };
    functionObj.hideLoading=function(){
      $ionicLoading.hide();
    };


    functionObj.showAlert = function(title,message) {
      var alertPopup = $ionicPopup.alert({
        title: title,
        template: message
      });
    };

    return functionObj;

}])


.factory('BlankFactory', [function(){

}])

.service('BlankService', [function(){

}]);