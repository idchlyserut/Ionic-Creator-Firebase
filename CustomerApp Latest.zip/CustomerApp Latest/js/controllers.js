angular.module('app.controllers', [])
  
.controller('homeCtrl', ['$scope', '$stateParams', '$firebaseArray', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName

function ($scope, $stateParams, $firebaseArray) {

 
    
    $scope.data = {
        'post':''
    };

      var ref = firebase.database().ref().child("news");
      // create a synchronized array
      $scope.news = $firebaseArray(ref);
      
      // add new items to the array
      // the message is automatically added to our Firebase database!
      $scope.addNews = function() {
        $scope.news.$add({
          title: $scope.data.title,
          text: $scope.data.text,
          //date:$scope.data.date
          
          
        });
        $scope.data.post = '';
      };
  
      
    
    
    /*
      var ref = firebase.database().ref().child("menu.news");
      // create a synchronized array
      $scope.news = $firebaseArray(ref);
      
      // add new items to the array
      // the message is automatically added to our Firebase database!
      $scope.addNews = function() {
        $scope.news.$add({
          title: $scope.data.title,
          text: $scope.data.text,
          //date:$scope.data.date
          
          
        });
        $scope.data.post = '';
      };
      */
}])
   
.controller('todaySSpecialCtrl', ['$scope', '$stateParams', '$firebaseArray', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName

function ($scope, $stateParams, $firebaseArray) {
  
    $scope.data = {
        'menus':''
    };

      var ref = firebase.database().ref().child("menu");
      // create a synchronized array
      $scope.menu = $firebaseArray(ref);
      
      // add new items to the array
      // the message is automatically added to our Firebase database!
      $scope.addMenu = function() {
        $scope.menu.$add({
          name: $scope.data.name,
          price: $scope.data.price
          
        });
        $scope.data.menus = '';
      };
	

}])
   
.controller('bookOurCateringCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('locateUsCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {

/*
($scope, $stateParams, $firebaseArray, $ionicUser) {
    
    $scope.data = [ {
        'booking': ''
    }
    ];
    
      var ref = firebase.database().ref().child("booking");
      // create a synchronized array
      $scope.booking = $firebaseArray(ref);
      
      // add new items to the array
      // the message is automatically added to our Firebase database!
      $scope.addBooking = function() {
        $scope.booking.$add({
          fullname: $scope.data.fullname,
          phoneNo: $scope.data.phoneNo,
          email: $scope.data.email,
          date: $scope.data.date
        });
        $scope.data.booking = '';
      };

} */
}])
   
.controller('calendarCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('settingsCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('menuCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('bookingFormCtrl', ['$scope', '$stateParams', '$firebaseArray', '$rootScope', '$firebaseObject', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $firebaseArray, $rootScope, $firebaseObject) {
    
    
    firebase.auth().onAuthStateChanged(user => {
        if(user) {
            $scope.user_info=user;
           let userId = firebase.auth().currentUser.uid;
            console.log(firebase.auth().currentUser.uid);
            console.log(user.email);
            var ref = firebase.database().ref('user').child(userId).child("booking");
            var refBook = firebase.database().ref('booking');
      // create a synchronized array
      $scope.booking = $firebaseArray(ref);
      
      $scope.data =  {
        //'bookings':''
       
        'fullname':'',
        'phoneNo':'',
        'email':'',
        'occasion': '',
        'date' : '',
        'time':'',
        'venue':'',
        'size': ''
        
    };
      
     
      $scope.addBooking = function() {
        // $scope.userId.booking.$add({
        ref.push({
            fullname: $scope.data.fullname,
            phoneNo: $scope.data.phoneNo,
            email: $scope.data.email,
            occasion: $scope.data.occasion,
            date: $scope.data.date.toString(),
            time: $scope.data.time.toString(),
            venue: $scope.data.venue,
            size: $scope.data.size,
        }
            )
            
        refBook.push({
            fullname: $scope.data.fullname,
            phoneNo: $scope.data.phoneNo,
            email: $scope.data.email,
            occasion: $scope.data.occasion,
            date: $scope.data.date.toString(),
            time: $scope.data.time.toString(),
            venue: $scope.data.venue,
            size: $scope.data.size,
        }
            )
        
          //user_id: $scope.user_info.uid
        // });
        }
        }
});
    
    /*
    $rootScope.extras=true;

    //Check if user already logged in
    firebase.auth().onAuthStateChanged(function(user) {
      if (user) {
        
        $scope.user_info=user;
        $scope.booking= $firebaseArray(firebase.database().refUser().child(user_info.uid).child("booking") );
        $scope.booking= $firebaseArray(fireBaseData.ref().child("booking"));
        
        //$scope.addresses= $firebaseArray(fireBaseData.refUser().child(user.uid).child("device"));
    

    // $scope.addresses= $firebaseArray(fireBaseData.refUser().child("user").child(user.uid));
    // $scope.addresses= $firebaseArray(fireBaseData.ref().child("device").child(user.uid));
    $scope.user_extras= $firebaseObject(fireBaseData.refUser().child(user.uid));
    $scope.user_info=user; //Saves data to user_info
    $scope.$apply();
    sharedUtils.hideLoading();
        //$scope.user_info=user;
      }
    });
    
    
    
  
    /*
    
    $scope.formatDate (date: Date): string {
        const day = date.getDate();
        const month = date.getMonth() + 1 ;
        const year = date.getYear();
        
        return '${day} - ${month} - ${year}';
        
    }
    */
    
    //Component({
       // selector: date-pipe,
        
       // {{today | date:'fullDate'}}
        //{{today | date:'h:mm a z'}}
        
    //});
    // Get the current date and time as a date-time value.
    //export class DatePipeComponent {
   //     date: number = Date.now();
  //  }
  
        //var userid= user.uid;
    
    
    //var userId = firebase.auth().currentUser.uid;
      //var ref = firebase.database().ref().child("booking");
      
      // add new items to the array
      // the message is automatically added to our Firebase database!
      //firebase.database().ref('booking').function($scope.addBooking());
      //firebase.database().ref('user').child($scope.user_info.uid).child("booking").push({
     
      //});
       /*
      firebase.databa.refBooking().push({
      user_id: $scope.user_info.uid,
      fullname: $scope.data.fullname,
          phoneNo: $scope.data.phoneNo,
          email: $scope.data.email,
          occasion: $scope.data.occasion,
          date: $scope.data.date.toString(),
          time: $scope.data.time.toString(),
          venue: $scope.data.venue,
          size: $scope.data.size
      });
      */
      
      //fireBaseData.refUser().child(result.uid).set({
        //      $scope.booking = $firebaseArray(ref);
          //  });

      
        
        
        //$scope.data.booking = '';
    //     console.log("Submitted in firebase");
          
    //   };
      
    //   //user_id: $scope.user_info.uid,
      
    // $rootScope.extras=true;

    /*
    
    $scope.addBooking = function(res) {
  

    firebase.database().refUser().child($scope.user_info.uid).child("booking").push({    // set
      
        fullname: res.fullname,
        phoneNo: res.phoneNo,
          email: res.email,
          occasion: res.occasion,
          date: res.date.toString(),
          time: res.time.toString(),
          venue: res.venue,
          size: res.size,
          
          
      });

   firebase.database().ref().child("booking").push({    // set
        fullname: res.fullname,
        phoneNo: res.phoneNo,
          email: res.email,
          occasion: res.occasion,
          date: res.date.toString(),
          time: res.time.toString(),
          venue: res.venue,
          size: res.size,
        
        user_id: $scope.user_info.uid,
        //user_name: $scope.user_info.displayName

        });

  




};
*/
}])
   
.controller('reviewFormCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {

$scope.data = {
    
        'fullname': $stateParams.fullname,
        'phoneNo': $stateParams.phoneNo,
        'email':  $stateParams.email,
        'occasion': $stateParams.occasion,
        'date': $stateParams.date,
        'time': $stateParams.time,
        'venue': $stateParams.venue,
        'size': $stateParams.size
    };

   
}
      
      
])
   
.controller('galleryCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('aboutUsCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {
$scope.data = {
    
        'fullname': $stateParams.fullname,
        'phoneNo': $stateParams.phoneNo,
        'email':  $stateParams.email,
        'occasion': $stateParams.occasion,
        'date': $stateParams.date,
        'time': $stateParams.time,
        'venue': $stateParams.venue,
        'size': $stateParams.size
    };

}])
   
.controller('successfulBookingCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {

    $scope.data = {
    
        'date': $stateParams.date
        
    };
}])
   
.controller('feedbackSubmissionCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('supportCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('newsCtrl', ['$scope', '$stateParams', '$ionicPopup', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName

function ($scope, $stateParams, $ionicPopup) {
  $scope.data = {
        'title': $stateParams.title,
        'text': $stateParams.text,
        //date': $stateParams.date
    };
}])
   
.controller('feedbackCtrl', ['$scope', '$stateParams', '$firebaseArray', '$ionicPopup', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams,  $firebaseArray, $ionicPopup) {

     $scope.data = {
             'fname': '',
             'femai':'',
             'fmessage': '',
              }
              
      var ref = firebase.database().ref().child("feedbacks");
      // create a synchronized array
      $scope.feedbacks = $firebaseArray(ref);
      
      // add new items to the array
      // the message is automatically added to our Firebase database!
      $scope.addfeedbacks = function() {
        $scope.feedbacks.$add({
        fname: $scope.data.fname,
        femail: $scope.data.femail,
        fmessage: $scope.data.fmessage,
        })
      

    };

}
])
   
.controller('mapsExampleCtrl', ['$scope', 'uiGmapGoogleMapApi', function($scope, uiGmapGoogleMapApi) {
    // Do stuff with your $scope.
    // Note: Some of the directives require at least something to be defined originally!
    // e.g. $scope.markers = []

    // uiGmapGoogleMapApi is a promise.
    // The "then" callback function provides the google.maps object.
    uiGmapGoogleMapApi.then(function(maps){
        // Configuration needed to display the road-map with traffic
        // Displaying Ile-de-france (Paris neighbourhood)
        $scope.map = {
            center: {
              latitude: -23.598763,
              longitude: -46.676547
            },
            zoom: 13,
            options: {
                mapTypeId: google.maps.MapTypeId.ROADMAP, // This is an example of a variable that cannot be placed outside of uiGmapGooogleMapApi without forcing of calling the google.map helper outside of the function
                streetViewControl: false,
                mapTypeControl: false,
                scaleControl: false,
                rotateControl: false,
                zoomControl: false
            }, 
            showTraficLayer:true
        };
    });
}])
   
.controller('aboutApplicationCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('helpCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('signupCtrl', ['$scope', '$stateParams', '$firebaseAuth', '$state', '$firebaseArray', '$ionicHistory', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $firebaseAuth, $state, $firebaseArray, $ionicHistory) {
    
 /*   
    var uemail = "";
    var password = "";
    
    $scope.createNewAccount = function() {
    try {
        
        const userAuth = firebase.auth().createUserWithEmailAndPassword(uemail, password);
        var user = {
            uname: "",
           // phone: "",
           // address: "",
            uid: userAuth.uid,
            uemail: userAuth.email
        }
        writeUserData(user)
        console.log(user.uid);
    } catch (error) {
        console.log(error.message);
    }
}

function writeUserData(user) {
    firebase.database().ref('user' + user.uid).set(user).catch(error => {
        console.log(error.message)
    });
}
    */
    
    /*
    $rootScope.extras = false; // For hiding the side bar and nav icon

    $scope.signupEmail = function (formName, cred) {

      if (formName.$valid) {  // Check if the form data is valid or not

        sharedUtils.showLoading();

        //Main Firebase Authentication part
        firebase.auth().createUserWithEmailAndPassword(cred.uemail, cred.password).then(function (result) {

            //Add name and default dp to the Autherisation table
            result.updateProfile({
              displayName: cred.uname,
              //photoURL: "default_dp"
            }).then(function() {}, function(error) {});

            //Add phone number to the user table
            fireBaseData.refUser().child(result.uid).set({
              //telephone: cred.phone,
              uname: cred.name
            });

            //Registered OK
            $ionicHistory.nextViewOptions({
              historyRoot: true
            });
            $ionicSideMenuDelegate.canDragContent(true);  // Sets up the sideMenu dragable
            $rootScope.extras = true;
            sharedUtils.hideLoading();
            $state.go('menu.home', {}, {location: "replace"});

        }, function (error) {
            sharedUtils.hideLoading();
            sharedUtils.showAlert("Please note","Sign up Error");
        });

      }else{
        sharedUtils.showAlert("Please note","Entered data is not valid");
      }

    }
    
    */
    
    
    
    var auth = $firebaseAuth();
    var ref = firebase.database().ref('user');
    var user = $firebaseArray(ref);
    
    $scope.data = {};
    
    $scope.signup = function(){
        auth.$createUserWithEmailAndPassword($scope.data.uemail, $scope.data.password).then(response=>{
            let userId = firebase.auth().currentUser.uid
            user.$add($scope.data);
            firebase.database().ref('user/' + userId).set({
              name: $scope.data.uname,
              email: $scope.data.uemail,
              //password: $scope.data.password,
              user_id: firebase.auth().currentUser.uid
            });
        $state.go('login');
        })
    // };
    
    // $scope.signupSuccessful = function(){
        // user.$add($scope.data);
        //firebase.database().ref('user'+ user.id).set({
        
    
        console.log("successfully made account");
        
            
    };
    
   
// For the JS SDK
//firebase.auth().onAuthStateChanged( user => {
  //if (user) { this.userId = user.uid }
//});
    
    /*
     firebase.auth().onAuthStateChanged(function (user) {
      if (user) {
        $scope.user_info = user;
        
        //$scope.bookings= $firebaseArray(firebase.database().ref('user').child(user.uid).child("booking"));

        firebase.database().ref('user').child('booking')
          .orderByChild('booking')
          .startAt($scope.user_info.uid).endAt($scope.user_info.uid)
          .once('value', function (snapshot) {
            $scope.books = snapshot.val();
            $scope.$apply();
          });
          //sharedUtils.hideLoading();
      }
    });
    */

}])
   
.controller('loginCtrl', ['$scope', '$stateParams', '$state', '$firebaseAuth', '$rootScope', '$ionicHistory', 'sharedUtils', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, $firebaseAuth, $rootScope, $ionicHistory, sharedUtils) {

   /*
    
    firebase.auth().onAuthStateChanged(user => {
        if(user) {
            console.log(user.uid);
            console.log(user.email);
            getUserData(user.uid);
            
        }
    });
   
    function getUserData(uid) {
    firebase.database().ref('users/' + uid).once("value", snap => {
        console.log(snap.val());
        const user = await ;firebase.auth().$signInWithEmailAndPassword(email, password);
    });
    }
    
    
    
    
    
    var email = "";
    var password = "";
    
    async; function createNewAccount() {
    try {
        const user = await ;firebase.auth().createUserWithEmailAndPassword(email, password);
        console.log(user.uid);
    } catch (error) {
        console.log(error.message);
    }
}

   */
   
   
   
  
   var auth = $firebaseAuth();
   
  $scope.data = {
   };
   
   $scope.login = function(){
       auth.$signInWithEmailAndPassword($scope.data.uemail, $scope.data.password).then($scope.loginSuccessful).catch($scope.loginError);
       
   };
   

   $scope.loginSuccessful = function(){
       
       $state.go('menu.home');
   };
   
   $scope.loginError = function(){
       console.log(error);
   };
   
   $scope.notSignup = function(){
       $state.go('signup');
   };
    
    
    /*
    
    $rootScope.extras = false;  // For hiding the side bar and nav icon

    // When the user logs out and reaches login page,
    // we clear all the history and cache to prevent back link
    $scope.$on('$ionicView.enter', function(ev) {
      if(ev.targetScope !== $scope){
        $ionicHistory.clearHistory();
        $ionicHistory.clearCache();
      }
    });




    //Check if user already logged in
    firebase.auth().onAuthStateChanged(function(user) {
      if (user) {

        $ionicHistory.nextViewOptions({
          historyRoot: true
        });
       // $ionicSideMenuDelegate.canDragContent(true);  // Sets up the sideMenu dragable
        $rootScope.extras = true;
        sharedUtils.hideLoading();
        $state.go('menu.home', {}, {location: "replace"});

      }
    });


    $scope.loginEmail = function(formName,cred) {


      if(formName.$valid) {  // Check if the form data is valid or not

          sharedUtils.showLoading();

          //Email
          firebase.auth().signInWithEmailAndPassword(cred.uemail,cred.password).then(function(result) {

                // You dont need to save the users session as firebase handles it
                // You only need to :
                // 1. clear the login page history from the history stack so that you cant come back
                // 2. Set rootScope.extra;
                // 3. Turn off the loading
                // 4. Got to menu page

              $ionicHistory.nextViewOptions({
                historyRoot: true
              });
              $rootScope.extras = true;
              sharedUtils.hideLoading();
              $state.go('menu.home', {}, {location: "replace"});

            },
            function(error) {
              sharedUtils.hideLoading();
              sharedUtils.showAlert("Please note","Authentication Error");
            }
        );

      }else{
        sharedUtils.showAlert("Please note","Entered data is not valid");
      }



    };


    

    $scope.loginGmail = function(){
      //Gmail Login
    };
    
    */

}])
   
.controller('bookingHistoryCtrl', ['$scope', '$stateParams', '$firebaseArray', '$ionicPopup', 'sharedUtils', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $firebaseArray, $ionicPopup, sharedUtils) {
    

    //$rootScope.extras = true;
   // sharedUtils.showLoading();
   
   //Check if user already logged in
    firebase.auth().onAuthStateChanged(function (user) {
      if (user) {
        
        $scope.user_info = user;
        let userId = firebase.auth().currentUser.uid;
        console.log(firebase.auth().currentUser.uid);
        console.log(user.email);
        
        
        var ref = firebase.database().ref('user').child(userId).child("booking");
        console.log(userId);
        $scope.booking = $firebaseArray(ref);
      
     
        
          //user_id: $scope.user_info.uid
        // });
        
        
        ref
        //firebase.database().ref('user').child('userId').child('booking')
          //.orderByChild(userId)
          //.startAt($scope.user_info.uid).endAt($scope.user_info.uid)
          .once('value', function (snapshot) {
            
            $scope.booking = snapshot.val();
            $scope.$apply();
            console.log(snapshot.val());
            console.log("hi");
          });
          
      }
    });
    
    /*
    
      $scope.Booking = function() {
        // $scope.userId.booking.$add({
        ref.push({
            fullname: $scope.data.fullname,
            phoneNo: $scope.data.phoneNo,
            email: $scope.data.email,
            occasion: $scope.data.occasion,
            date: $scope.data.date.toString(),
            time: $scope.data.time.toString(),
            venue: $scope.data.venue,
            size: $scope.data.size,
        });
      
           // getUserData(user.uid);
            
    
   /*
    function getUserData(uid) {
    firebase.database().ref('users/' + uid).once("value", snap => {
        console.log(snap.val());
    });
    }
    
    
    
   
    
    //Check if user already logged in
    firebase.auth().onAuthStateChanged(function (user) {
      if (user) {
        $scope.user_info = user;
        
        //$scope.bookings= $firebaseArray(firebase.database().ref('user').child(user.uid).child("booking"));
        
        fireBaseData.refBook()
        .orderByChild('user_id')
        .startAt($scope.user_info.uid).endAt($scope.user_info.uid)
        .once('value', function (snapshot) {
          $scope.books = snapshot.val();
          $scope.$apply();
        });
        sharedUtils.hideLoading();
    }
  });
        
        /*
        firebase.database().ref('user').child('booking')
          .orderByChild('booking')
          .startAt($scope.user_info.uid).endAt($scope.user_info.uid)
          .once('value', function (snapshot) {
            $scope.books = snapshot.val();
            $scope.$apply();
          });
          //sharedUtils.hideLoading();
      }
    });
    
  
    
    $scope.data = {
        'booking':''
    };
    
    //Component({
       // selector: date-pipe,
        
       // {{today | date:'fullDate'}}
        //{{today | date:'h:mm a z'}}
        
    //});
    // Get the current date and time as a date-time value.
    //export class DatePipeComponent {
   //     date: number = Date.now();
  //  }
    
      //var ref = firebase.database().refUser().child("booking");
      // create a synchronized array
      $scope.booking = $firebaseArray(ref);
      
      // add new items to the array
      // the message is automatically added to our Firebase database!
        /*
      $scope.addBooking = function() {
        $scope.booking.$add({
          fullname: $scope.data.fullname,
          phoneNo: $scope.data.phoneNo,
          email: $scope.data.email,
          occasion: $scope.data.occasion,
          date: $scope.data.date,
          time: $scope.data.time,
          venue: $scope.data.venue,
          size: $scope.data.size
        });
        $scope.data.booking = '';
      };
      */


    /*
    $scope.showDelete=false;
    $scope.showReorder=false;
    
    $scope.toggle= function (v) {
        $scope[v] = !$scope[v];
    } ;
    $scope.delete = function (booking){
        $scope.booking.splice($scope.booking.indexOf(booking), 1);
       // $scope.booking.$remove(booking);
        alert ('Booking Deleted');
    };
    
    $scope.reorder = function(booking,fromIndex,toIndex) {
        $scope.booking.splice(fromIndex,1);
        $scope.booking.splice(toIndex,0, booking);
    };
   
  //firebase.database.ref().push({});
    $scope.removePost=function(booking){
      //$scope.news.$remove(post);
     firebase.database().ref().child("booking").remove();
    };
    
    $scope.deletePost = function(del_id) {
      var confirmPopup = $ionicPopup.confirm({
        title: 'Delete Booking',
        template: 'Are you sure you want to delete this booking',
        buttons: [
          { text: 'No' , type: 'button-light' },
          { text: 'Yes', type: 'button-assertive' , onTap: function(){return del_id;} }
        ]
      });

      confirmPopup.then(function(res) {
        if(res) {
          firebase.database().ref().child("booking").child(res).remove();
        }
      });
    };
    */
    
}])
   
.controller('bookingInformationCtrl', ['$scope', '$stateParams', '$firebaseArray', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $firebaseArray) {
    

$scope.data = {
    
        'fullname': $stateParams.fullname,
        'phoneNo': $stateParams.phoneNo,
        'email':  $stateParams.email,
        'occasion': $stateParams.occasion,
        'date': $stateParams.date,
        'time': $stateParams.time,
        'venue': $stateParams.venue,
        'size': $stateParams.size
    };
      


}])
 